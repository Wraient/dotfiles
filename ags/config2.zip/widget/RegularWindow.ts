import Gtk from "gi://Gtk?version=3.0"

export default Widget.subclass<typeof Gtk.Window, Gtk.Window.ConstructorProperties>(Gtk.Window)
